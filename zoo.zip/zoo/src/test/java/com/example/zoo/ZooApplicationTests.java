package com.example.zoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZooApplicationTests {

	@Test
	void contextLoads() {
	}

}
